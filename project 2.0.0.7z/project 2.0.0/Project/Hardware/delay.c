#include "delay.h"
#include "headfile.h"
  

void Delay100ms()		//@24.000MHz
{
	unsigned long i;

	_nop_();
	_nop_();
	i = 599998UL;
	while (i) i--;
}

void Delay10ms()		//@24.000MHz
{
	unsigned long i;

	_nop_();
	_nop_();
	_nop_();
	i = 59998UL;
	while (i) i--;
}


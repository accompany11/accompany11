#ifndef __DELAY_H
#define __DELAY_H
#include "headfile.h"

void Delay100ms(void);
void Delay10ms(void);
#endif
#ifndef __LED_H
#define __LED_H
#include "headfile.h"

void LED_ON(void);
void LED_OFF(void);
void LED_RING_ENTERING(void);
void LED_normal(void);
#endif
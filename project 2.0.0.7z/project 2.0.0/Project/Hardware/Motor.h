#ifndef __Motor_H
#define __Motor_H
#include "headfile.h"
#define speed_MAX 300
#define speed_MIN -300

#define DIR_1 P60
#define DIR_2 P64
#define PWM_1 PWMA_CH2P_P62
#define PWM_2 PWMA_CH4P_P66

#define Speed_MAX 300 
#define Speed_MIN 300

void Motor_init(void);
void Motor_go (void);
void left (void);
void right (void);
void Motor2_SetSpeed(float PWM_Right);
void Motor1_SetSpeed(float PWM_Left);
#endif
#ifndef __SERVO_H
#define __SERVO_H
#include "headfile.h"
void servo_init(void);
void servo_set_angle(float angle);



#endif
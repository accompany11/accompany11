#ifndef __BEEP_H
#define __BEEP_H
#include "headfile.h"

void BEEP_ON(void);
void BEEP_OFF(void);
#endif
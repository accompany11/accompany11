#ifndef __KEY_H
#define __KEY_H
#include "headfile.h"
void KEY_init(void);

#endif
#include "LED.h"
#include "headfile.h"

void LED_ON()
{    // ����P5.2Ϊ�������ģʽ
 gpio_mode(P5_2,GPO_PP);
    P52= 0; 
}
void LED_OFF()
{    // ����P5.2Ϊ�������ģʽ
 gpio_mode(P5_2,GPO_PP);


    P52= 1; 
}
void LED_RING_ENTERING()
{    
LED_ON();
	delay_ms(20);
LED_OFF();
	delay_ms(20);
LED_ON();
	delay_ms(20);
LED_OFF();	
}


void LED_normal()
{    
LED_ON();
	delay_ms(500);
LED_OFF();
	delay_ms(500);
LED_ON();
	delay_ms(500);
LED_OFF();
LED_ON();
	delay_ms(500);
LED_OFF();
	delay_ms(500);
LED_ON();
	delay_ms(500);
LED_OFF();	
}
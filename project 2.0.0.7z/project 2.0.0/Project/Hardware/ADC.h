#ifndef __ADC_H
#define __ADC_H
#include "headfile.h"

void Battery(void);//��ʼ������ADC���IO��

void Adinductance_init(void);
float ADC_Del_MaxMin_Average_Filter(float *ADC);
uint16 ADC_average_filter (ADCN_enum adcn, ADCRES_enum resolution, uint8 count);
void ADC_Final_Read_Deal();
int16 ADC_Limit(int16 in_adc,int8 max,int8 min);

float fbs_output(float input);
double Calculate_Weight(double L);
void Calculate_Error(void);
void ADC_allinit(void);
void ADC_display(void);//��ʾ����Ļ��

#endif
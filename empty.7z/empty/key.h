#ifndef __key_H__
#define	__key_H__

#include "ti_msp_dl_config.h"

void key_Init(void);

#endif
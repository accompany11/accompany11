#ifndef __led_H__
#define	__led_H__

#include "ti_msp_dl_config.h"
void LED_ON(void);
void LED_OFF(void);
#endif
#ifndef __servo_H__
#define	__servo_H__

#include "ti_msp_dl_config.h"

void SERVO_SetAngle1(float Angle);
void SERVO_SetAngle2(float Angle);

#endif
#ifndef __encoder_H__
#define	__encoder_H__

#include "ti_msp_dl_config.h"

void GROUP1_IRQHandler(void);

#endif
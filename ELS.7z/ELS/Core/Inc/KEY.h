#include "main.h"   // 必须包含HAL库核心头文件[1,3](@ref)
#ifndef __KEY_H
#define __KEY_H


void  Key1_Scan();
void OLED_UpdateDisplay(void);
void  Key2_Scan();
void  Key3_Scan();


#endif

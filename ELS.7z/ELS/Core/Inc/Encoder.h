#ifndef __Encoder_H__
#define __Encoder_H__
int EncoderL_GetSpeed(void);
int EncoderR_GetSpeed(void);

void Encoder_Init(void);
void Encoder_SetZero(void);
#endif 

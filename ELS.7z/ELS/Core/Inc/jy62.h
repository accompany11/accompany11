#ifndef __JY61P_H
#define __JY61P_H

#include "main.h" 

void jy62_ReceiveData(uint8_t RxData);

extern int16_t Roll,Pitch,Yaw;

#endif
